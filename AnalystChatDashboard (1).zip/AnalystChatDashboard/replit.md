# Juegos 3°A - Colegio del Prado

## Overview

This is a React-based web application that serves as a portfolio/showcase for games developed by 3rd grade students ("3°A") in the Technology subject at Colegio del Prado. The application provides a landing page with cards linking to three different games:

1. **Juego de Memoria** - A color memory game with sequences
2. **Palabra Secreta** - A word puzzle/anagram game
3. **Aventura Arcade** - An external MakeCode Arcade game

The application follows a modern web architecture with a React frontend built using Vite, styled with Tailwind CSS and shadcn/ui components. The backend is minimal Express.js setup with scaffolding for future expansion.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Build Tool**
- **React 18** with TypeScript for the UI layer
- **Vite** as the build tool and development server
- **Wouter** for lightweight client-side routing (instead of React Router)

**Design System**
- **shadcn/ui** component library built on Radix UI primitives
- **Tailwind CSS** for utility-first styling with custom design tokens
- **Design Philosophy**: Inspired by Carbon Design System for data-heavy applications, though this specific app is a simple game showcase. The design includes references to Linear, Notion, and Tableau for clean, efficient UI patterns.

**Styling Approach**
- Custom CSS variables defined in `index.css` for theme tokens (light/dark mode support)
- Tailwind configuration extends default theme with custom border radius, colors, and shadows
- Component-level styling uses `cn()` utility (clsx + tailwind-merge) for conditional classes

**State Management**
- **TanStack Query (React Query)** for server state management and data fetching
- Local component state using React hooks
- Toast notifications via custom `useToast` hook

**Theme System**
- Light/dark mode toggle with localStorage persistence
- Theme preference detection from system settings
- CSS custom properties for color tokens that adapt to theme

### Backend Architecture

**Server Framework**
- **Express.js** with TypeScript for the HTTP server
- **Development Mode**: Vite middleware integration for HMR and dev server
- **Production Mode**: Serves static built assets

**Data Layer (Scaffolded)**
- **Drizzle ORM** configured for PostgreSQL via `@neondatabase/serverless`
- Schema defined in `shared/schema.ts` with a basic Users table
- In-memory storage implementation (`MemStorage`) as a placeholder/development option
- Database migrations directory structure in place

**API Design**
- RESTful API structure with `/api` prefix convention
- Request logging middleware tracking method, path, status, duration, and response preview
- JSON body parsing with raw body preservation for webhooks

**Session Management (Scaffolded)**
- `connect-pg-simple` dependency suggests PostgreSQL-backed sessions are intended
- No active authentication implementation currently

### Project Structure

```
client/
  public/          # Static HTML games (juego-memoria.html, palabra-secreta.html)
  src/
    components/    # React components including full shadcn/ui library
    pages/         # Route components (home, not-found)
    hooks/         # Custom React hooks (use-toast, use-mobile)
    lib/           # Utilities (queryClient, cn helper)
    index.css      # Global styles and CSS custom properties
    main.tsx       # Application entry point
    App.tsx        # Router and providers setup

server/
  index.ts         # Express server setup and middleware
  routes.ts        # Route registration (minimal implementation)
  storage.ts       # Storage interface and in-memory implementation
  vite.ts          # Vite dev server integration

shared/
  schema.ts        # Database schema definitions (Drizzle)

attached_assets/   # Original game files (game1, game2)
```

### Routing Strategy

- **Client-side routing** handled by Wouter (lightweight, ~1.2KB)
- **Single route** currently implemented: home page (`/`)
- **Static HTML games** accessed directly via `/juego-memoria.html` and `/palabra-secreta.html`
- **External game** links to MakeCode Arcade hosted content
- Links open in new tabs with security attributes (`noopener,noreferrer`)

### Component Architecture

**UI Component Library**
- Full shadcn/ui component set imported (40+ components)
- Components are customizable via variant props (CVA - class-variance-authority)
- Accessibility built-in via Radix UI primitives
- Consistent styling through shared variants and design tokens

**Key Patterns**
- Compound components (e.g., Card, CardHeader, CardContent)
- Polymorphic components using Radix Slot for flexible composition
- Forwarded refs for all components to support advanced patterns
- TypeScript for full type safety across components

### Design System Tokens

**Typography**
- Primary: Inter (via Google Fonts)
- Monospace: JetBrains Mono, Fira Code, Geist Mono
- Font family: DM Sans, Architects Daughter (for playful/handwritten elements)

**Spacing**
- Tailwind's default spacing scale
- Custom values: 2, 4, 6, 8 units for component spacing

**Colors**
- HSL-based color system with CSS custom properties
- Separate tokens for foreground, background, border
- Semantic colors: primary, secondary, accent, destructive, muted
- Chart colors defined for data visualization (though not used in current app)

**Elevation**
- Shadow utilities: shadow-xs, shadow-sm, shadow-md, shadow-lg
- Hover/active states via `hover-elevate` and `active-elevate` classes

## External Dependencies

### Core Frontend Dependencies
- **React & React DOM** (v18+) - UI framework
- **Vite** - Build tool and dev server with HMR
- **TypeScript** - Type safety across the stack
- **Wouter** - Lightweight routing library

### UI & Styling
- **Tailwind CSS** - Utility-first CSS framework
- **shadcn/ui components** - Pre-built accessible components
- **Radix UI** - Primitive components (~25 packages for dialogs, dropdowns, tooltips, etc.)
- **class-variance-authority** - Type-safe component variants
- **tailwind-merge** & **clsx** - Conditional className utilities
- **lucide-react** - Icon library
- **cmdk** - Command palette component
- **embla-carousel-react** - Carousel component
- **react-day-picker** - Date picker
- **recharts** - Charting library (imported but not actively used)
- **vaul** - Drawer component

### Backend Dependencies
- **Express** - Web server framework
- **Drizzle ORM** - Type-safe ORM for PostgreSQL
- **@neondatabase/serverless** - Neon PostgreSQL client for serverless environments
- **drizzle-zod** - Zod schema generation from Drizzle tables
- **connect-pg-simple** - PostgreSQL session store
- **tsx** - TypeScript execution for development

### Development Tools
- **@replit/vite-plugin-runtime-error-modal** - Runtime error overlay
- **@replit/vite-plugin-cartographer** - Replit integration (dev only)
- **@replit/vite-plugin-dev-banner** - Development banner (dev only)
- **esbuild** - JavaScript bundler for server code
- **drizzle-kit** - Database migration tool

### Form Management & Validation
- **react-hook-form** - Form state management
- **@hookform/resolvers** - Validation resolvers
- **zod** - Schema validation library

### Data Fetching
- **@tanstack/react-query** - Server state management
- **date-fns** - Date utility library

### Fonts
- **Google Fonts**: Inter, DM Sans, Architects Daughter, Fira Code, Geist Mono

### Database
- **PostgreSQL** via Neon serverless driver
- Connection string required via `DATABASE_URL` environment variable
- Drizzle migrations configured to output to `./migrations` directory

### Session Store (Configured but Not Active)
- PostgreSQL-backed sessions via `connect-pg-simple`
- Express session handling scaffolded but not implemented