# Design Guidelines: Data Analytics Platform with AI Chatbot

## Design Approach

**System Selected: Carbon Design System** (IBM's design system for data-heavy enterprise applications)

**Justification:** This is a utility-focused productivity tool for analysts requiring information-dense layouts, strong data visualization capabilities, and reliable interaction patterns. Carbon excels at complex data interfaces while maintaining clarity and usability.

**Reference Inspiration:**
- Tableau/Looker: Dashboard grid systems and chart organization
- Linear: Clean, efficient UI with excellent information hierarchy
- Notion: Flexible layout builder patterns
- Intercom: Chat interface design

## Core Design Elements

### Typography
- **Primary Font:** Inter (Google Fonts) - exceptional readability for data-heavy interfaces
- **Monospace Font:** JetBrains Mono - for data tables, code snippets, numerical values
- **Hierarchy:**
  - Page Titles: text-2xl font-semibold (Dashboard Builder, Data Upload)
  - Section Headers: text-lg font-medium (Chart Configuration, Dataset Info)
  - Widget Titles: text-base font-medium
  - Body/Data: text-sm regular
  - Captions/Meta: text-xs text-gray-600

### Layout System

**Spacing Units:** Tailwind units of 2, 4, 6, and 8 (p-2, m-4, gap-6, space-y-8)
- Consistent 6-unit gaps between major sections
- 4-unit padding for cards and panels
- 2-unit spacing for tightly grouped elements

**Grid Structure:**
- Dashboard canvas: 12-column responsive grid for widget placement
- Sidebar: Fixed 280px width on desktop, slide-over on mobile
- Main content area: flex-1 with max-w-7xl container
- Chat panel: 380px fixed width, collapsible

### Component Library

#### Navigation & Layout
- **Top Navigation Bar:** Fixed header with app logo, dataset selector dropdown, user profile
- **Left Sidebar:** Collapsible panel with sections for Data Sources, Saved Dashboards, Widget Library
- **Main Canvas:** Drag-and-drop grid area for dashboard composition
- **Right Panel (Chat):** Slide-in chatbot interface, toggleable

#### Data Components
- **File Upload Zone:** Dashed border dropzone with upload icon, file type indicators, drag state feedback
- **Data Preview Table:** Sticky header, zebra striping (subtle), sortable columns, pagination controls
- **Chart Widgets:** Consistent card wrapper with title bar, configuration icon, resize handles
  - Bar Charts, Line Graphs, Pie Charts, Scatter Plots
  - Unified toolbar: chart type selector, data mapping controls, color scheme picker
- **KPI Cards:** Large numerical display, trend indicator, sparkline preview, comparison metric
- **Data Table Widget:** Virtual scrolling for large datasets, column filtering, export button

#### Interactive Elements
- **Widget Palette:** Icon-based grid showing available chart types, drag to add
- **Configuration Panel:** Slide-out form for chart settings (axes, filters, aggregations)
- **Dashboard Actions:** Toolbar with Save, Export, Share, Reset Layout buttons
- **Chat Interface:**
  - Message bubbles: User (right-aligned, different background), AI (left-aligned)
  - Input field with send button and file attachment option
  - Suggested queries as clickable chips
  - Code snippets with syntax highlighting for SQL/data queries

#### Forms & Controls
- **Dropdowns:** Clean select menus for dataset/column selection
- **Toggle Switches:** For boolean options (show legend, enable filters)
- **Range Sliders:** For numerical filters and date ranges
- **Button Hierarchy:**
  - Primary: Solid background (Save Dashboard, Apply Changes)
  - Secondary: Outlined (Cancel, Reset)
  - Tertiary: Ghost/text-only (Clear filters)

### Visual Patterns

**Cards & Panels:**
- Subtle border (border border-gray-200)
- Minimal shadow (shadow-sm)
- Rounded corners (rounded-lg)
- Clean internal padding (p-4 to p-6)

**Data Density:**
- Compact spacing for tables and lists
- Efficient use of vertical space
- Clear visual separation between sections without excessive whitespace
- Grid layouts: gap-4 for tight grouping, gap-6 for distinct sections

**State Indicators:**
- Loading: Subtle skeleton loaders matching component structure
- Empty states: Icon + descriptive text + primary action
- Error states: Inline validation messages, toast notifications for system errors
- Active/selected: Highlight border or background tint, not bold transformations

### Interactions

**Drag & Drop:**
- Widget library → Canvas: Visual preview follows cursor
- Dashboard reorganization: Grid snap guides, drop zones highlighted
- File upload: Dropzone border changes on drag-over

**Chart Interactions:**
- Hover tooltips: Data point details with formatted values
- Click legends: Toggle series visibility
- Zoom/pan: For time-series and scatter plots
- No animations on data updates (instant refresh for performance)

**Chat Behavior:**
- Auto-scroll to latest message
- Typing indicators for AI responses
- Message actions: Copy, regenerate, insert to dashboard

### Accessibility
- Semantic HTML throughout (main, nav, aside, section)
- ARIA labels for all interactive elements
- Keyboard navigation: Tab through widgets, arrow keys for grid navigation
- Focus indicators: 2px outline on all focusable elements
- Color contrast: WCAG AA minimum for all text
- Screen reader announcements for dynamic content updates

### Icons
**Library:** Heroicons (via CDN)
- Outline style for toolbar and navigation
- Solid style for active states and emphasis
- 20px base size (w-5 h-5), 16px for inline (w-4 h-4)

### Performance Considerations
- Virtualized rendering for large data tables
- Debounced search and filter inputs
- Lazy load chart libraries as needed
- Minimal re-renders: memoize chart components

### No Images Required
This is a data-focused application tool, not a marketing site. No hero images or decorative photography needed. Focus on clear information architecture and functional design.