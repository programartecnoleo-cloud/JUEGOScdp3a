import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ExternalLink, Play } from "lucide-react";

export default function Home() {
  const games = [
    {
      id: 1,
      title: "Juego de Memoria",
      subtitle: "Cartucheras de Colores",
      description: "Pon a prueba tu memoria recordando la secuencia de colores",
      icon: "🎨",
      color: "from-cyan-500 to-blue-600",
      link: "/juego-memoria.html",
      type: "local"
    },
    {
      id: 2,
      title: "Palabra Secreta",
      subtitle: "Adivina el Anagrama",
      description: "Descifra las palabras mezcladas antes de que se acabe el tiempo",
      icon: "🔤",
      color: "from-green-500 to-emerald-600",
      link: "/palabra-secreta.html",
      type: "local"
    },
    {
      id: 3,
      title: "Aventura Arcade",
      subtitle: "MakeCode Arcade",
      description: "Explora un mundo de aventuras en este juego creado con MakeCode",
      icon: "🎮",
      color: "from-yellow-500 to-orange-600",
      link: "https://arcade.makecode.com/S34553-18888-61830-80373",
      type: "external"
    }
  ];

  const handlePlay = (link: string, type: string) => {
    window.open(link, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <header className="flex items-center gap-6 mb-12 pb-6 border-b-2 border-primary/20">
          <img 
            src="/logo-colegio.jpg" 
            alt="Colegio del Prado" 
            className="w-24 h-24 object-contain drop-shadow-lg"
            data-testid="img-logo"
          />
          <div>
            <h1 className="text-5xl font-bold bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent" data-testid="text-title">
              Juegos de 3°A
            </h1>
            <p className="text-xl text-muted-foreground mt-2" data-testid="text-subtitle">
              Proyecto integrador: Biología y Tecnología
            </p>
            <p className="text-sm text-muted-foreground mt-1">
              Colegio del Prado
            </p>
          </div>
        </header>

        <div className="mb-10">
          <h2 className="text-3xl font-semibold text-foreground mb-3">
            Nuestros Proyectos
          </h2>
          <p className="text-lg text-muted-foreground">
            ¡Descubrí los juegos que creamos! Hacé click en "Jugar" para comenzar.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {games.map((game) => (
            <Card 
              key={game.id} 
              className="overflow-hidden hover-elevate border-2 transition-all duration-300 group"
              data-testid={`card-game-${game.id}`}
            >
              <div className={`h-40 bg-gradient-to-br ${game.color} flex items-center justify-center relative overflow-hidden`}>
                <div className="absolute inset-0 bg-black/10 group-hover:bg-black/0 transition-colors duration-300"></div>
                <span className="text-8xl transition-transform duration-300 group-hover:scale-110 relative z-10" role="img" aria-label={game.title}>
                  {game.icon}
                </span>
              </div>
              
              <CardContent className="p-6">
                <div className="mb-5">
                  <h3 className="text-2xl font-bold text-foreground mb-1 group-hover:text-primary transition-colors" data-testid={`text-game-title-${game.id}`}>
                    {game.title}
                  </h3>
                  <p className="text-sm font-semibold text-accent mb-3">
                    {game.subtitle}
                  </p>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {game.description}
                  </p>
                </div>

                <Button
                  className="w-full font-bold text-base"
                  size="lg"
                  onClick={() => handlePlay(game.link, game.type)}
                  data-testid={`button-play-${game.id}`}
                >
                  {game.type === 'external' ? (
                    <>
                      <ExternalLink className="w-5 h-5 mr-2" />
                      Jugar en MakeCode
                    </>
                  ) : (
                    <>
                      <Play className="w-5 h-5 mr-2" />
                      Jugar Ahora
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-20 mb-12 p-8 bg-gradient-to-r from-primary/10 via-accent/10 to-secondary/10 rounded-xl border-2 border-primary/20">
          <div className="max-w-3xl mx-auto text-center">
            <h3 className="text-2xl font-bold text-foreground mb-4">
              💡 Beneficios de los Juegos Educativos
            </h3>
            <p className="text-base text-muted-foreground leading-relaxed">
              Estos juegos no solo son divertidos, sino que también ejercitan tu cerebro de manera activa. 
              Al jugarlos, estimulás la memoria, la concentración y el pensamiento lógico. 
              Mantener el cerebro activo a través de desafíos mentales como estos ayuda a fortalecer las conexiones neuronales, 
              lo que puede contribuir a una mejor salud cognitiva y reducir el riesgo de desarrollar 
              enfermedades neurodegenerativas en el futuro. ¡Un cerebro ejercitado es un cerebro saludable!
            </p>
          </div>
        </div>

        <footer className="mt-12 text-center text-sm text-muted-foreground border-t pt-8">
          <p className="mb-2">
            <span className="font-semibold text-primary">Colegio del Prado</span> - 3°A
          </p>
          <p className="italic text-base font-medium text-foreground">
            "Saber, Ética y Amor"
          </p>
        </footer>
      </div>
    </div>
  );
}
